<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="wrap">
    <div class="container">
        <h1 class="title-404">404<span>页面丢失了，回 <a href="<?php $this->options->siteUrl(); ?>">首页</a> 吧。</span></h1>
    </div>
</div>
<?php $this->need('footer.php'); ?>
