<div class="footer">
    <div class="container">
        <p><a href="<?php $this->options->feedUrl(); ?>">RSS</a></p>
        <p>&copy;<span class="copyright-year">0000</span> <a href="<?php $this->options->siteUrl(); ?>" class="link" target="_blank"><?php $this->options->title() ?></a></p>
        <p>Theme by <a href="http://ryli.pw/" class="link" target="_blank">RY</a> - Powered by <a href="http://typecho.org/" class="link" target="_blank">Typecho</a></p>
    </div>
</div>

<div class="mask">
    <div class="nav-slider">
        <div class="nav-slider-inner">
            <ul>
                <li class="close"><a href="javascript:;"><span></span></a></li>
                <li class="search">
                    <form method="post" action="">
                        <input type="search" name="s" class="text" placeholder="关键词输入后回车搜索">
                        <!--<input type="submit" class="submit" value="Search">-->
                    </form>
                </li>
                <?php $this->widget('Widget_Metas_Category_List')->parse('<li><a href="{permalink}">{name}</a></li>'); ?>
                <?php $this->widget('Widget_Contents_Page_List')->parse('<li><a href="{permalink}">{title}</a></li>'); ?>
            </ul>
        </div>
    </div>
</div>

<div class="back-to-top">top</div>

<script src="//cdn.bootcss.com/jquery/3.1.0/jquery.min.js"></script>
<script>
$(document).ready(function(e) {

    // 版权处年份
    var today = new Date();
    var year = today.getFullYear();
    $(".copyright-year").text(year);
    
    // 返回顶部
    $(".back-to-top").click(function(e) {
        $("body,html").animate({scrollTop:0},250);
    });
    
    // 导航
    $(".header ul li:last a").click(function(e) {
        $(this).fadeOut(250);
        $(".mask").fadeIn(250);
        $("body").css({
                "overflow":"hidden",
                "transform":"translateX(-240px)",
                "transition":"ease-in-out .25s"
            });
    });
    $(".nav-slider-inner ul li.close a").click(function(e) {
        $(".header ul li:last a").fadeIn(250);
        $(".mask").fadeOut(250);
        $("body").css({
                "overflow":"auto",
                "transform":"translateX(0)",
                "transition":"ease-in-out .25s"
            });
    });
    
});
</script>

</body>
</html>