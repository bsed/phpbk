	<div class="foot">
		
		<p><a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>&trade;&reg;&nbsp;本站内容遵循<a href="http://creativecommons.org/licenses/by-nc-sa/4.0/" target="_blank" rel="external nofollow" se_prerender_url="complete">知识共享署名-非商业性使用-相同方式共享 4.0 国际许可协议</a>.</p>
		</div><!-- end #footer -->
</div>
<?php $this->footer(); ?>
</div>
</body>
</html>
