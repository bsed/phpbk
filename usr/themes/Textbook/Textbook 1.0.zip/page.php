<?php $this->need('header.php'); ?>		
<div class="content">
		<?php $this->content(); ?>
	<?php $this->need('comments.php'); ?>
	</div>		
<?php $this->need('footer.php'); ?>