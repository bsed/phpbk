<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
			<footer class="footer">
				<a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title();?></a> / <a href="http://typecho.org/">自豪地采用Typecho</a>
			</footer>
		</div>
	</div>
<div id="backTop"></div>
<script src="<?php $this->options->themeUrl('js.js'); ?>"></script>
<?php $this->footer(); ?>
</body>
</html>
