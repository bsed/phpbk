### Typecho HTMLCompress Plugin

#### 简介
Typecho HTML Compression 是我移植的一款最简单但最实用的插件，它的主要作用是——删除前端页面所有空行和制表符等不必要的内容、简化代码，从而实现加速**(并不是)** Typecho 的效果。你甚至不需要做任何设置，下载，安装，启用。不要小看页面中的空行，删去后可以节省大量载入时间，这也就是为什么 jQuery、Bootstrap 等文件要提供“Uncompressed”和“Compressed”版的原因。

#### 声明
* 移植自同名WordPress插件 WP-HTML-Compression。
* 原作者 Steven Vachon
* 原作者主页 http://www.svachon.com/
* WordPress插件页 http://www.svachon.com/blog/html-minify/
* 简介中的点评抄袭自 http://www.mywpku.com/wp-html-compression.html