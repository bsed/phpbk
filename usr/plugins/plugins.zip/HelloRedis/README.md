* V1.1
 * 重构代码，卸载插件同时将同时清理您typecho的redis缓存功能.
 * 启用插件即安装，禁用插件即卸载
 * 此版为最终版不在提供更新服务 
 * 使用本插件请先在您的服务器上为php安装redis扩展，执行本插件将会自动为您的typecho配置redis，如果您网站有任何更新操作请在后台页面右上角点击刷新缓存，请不要随意修改本插件内容，转载请注明版权
 
 * @package HelloRedis
 * @author Angboo
 * @version 1.1.0
 * @link http://www.aecode.cn

 * 懒的打字信息如上，测试页面加载提速约100倍左右，开启后加载速度约在0.0002-0.0004秒之间。
 * 查看debug信息请访问http://域名/?debug=true,查看网页源代码底部可见.
