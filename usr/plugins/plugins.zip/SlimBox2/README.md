## 插件说明 ##

 - 版本: v1.0.5
 - 作者: [冰剑](https://github.com/binjoo)
 - 主页: <https://github.com/binjoo/SlimBox2-for-Typecho>

## 使用方法 ##

 1. 下载插件
 2. 如果安装有老版本，请先卸载老版本，再删除插件文件
 3. 将插件上传到 /usr/plugins/ 这个目录下
 4. 登陆后台，在“控制台”下拉菜单中进入“插件管理”
 5. 启用当前插件

## 更新记录 ##
#### v1.0.5
 - 使用[林木木的代码](http://immmmm.com/slimbox2-js-picture-box-adaptive.html)修复`图片灯箱自适应`功能；

#### v1.0.4
 - 加入标题栏显示隐藏；

#### v1.0.3
 - 加入图片循环；

#### v1.0.2
 - 加入Google CDN jQuery库；

#### v1.0.1
 - 加入插件后台；
 - 加入自定义计数器提示；

#### v1.0.0
 - 实现灯箱展示效果；